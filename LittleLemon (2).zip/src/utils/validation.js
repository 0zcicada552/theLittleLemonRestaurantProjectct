export const validateBooking = (formData) => {
  const errors = {};
  if (!formData.name) errors.name = "Name is required.";
  if (!formData.date) errors.date = "Date is required.";
  if (!formData.time) errors.time = "Time is required.";
  if (formData.guests < 1) errors.guests = "Guests must be at least 1.";
  return errors;
};
