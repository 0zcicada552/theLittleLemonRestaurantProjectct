import React from "react";
import "./About.css";

function About() {
  return (
    <div className="about">
      <h1>About Little Lemon</h1>
      <p>We serve the best dishes with fresh ingredients and love.</p>
    </div>
  );
}

export default About;
