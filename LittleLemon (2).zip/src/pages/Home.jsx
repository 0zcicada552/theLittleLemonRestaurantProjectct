import React from "react";
import "./Home.css";

function Home() {
  return (
    <div className="home">
      <h1>Welcome to Little Lemon</h1>
      <p>Your cozy place for delicious meals and unforgettable moments!</p>
    </div>
  );
}

export default Home;
