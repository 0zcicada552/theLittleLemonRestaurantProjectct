import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 2024 Little Lemon. Built by Iloko Lokuli Benel. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
