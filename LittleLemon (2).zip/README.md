# Little Lemon Restaurant App
This is the official web application for the Little Lemon restaurant, built using React.

## Features
- Responsive design
- Navigation between pages

## Author
Built by **Iloko Lokuli Benel**.

## License
&copy; 2024 Little Lemon. All rights reserved.
